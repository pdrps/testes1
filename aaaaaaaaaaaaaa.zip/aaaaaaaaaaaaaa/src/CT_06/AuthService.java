package CT_06;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.HashMap;
import java.util.Map;

// Classe que simula o sistema de autenticação
class AuthService {
    private final Map<String, String> registeredUsers = new HashMap<>();

    // Registra um novo usuário no sistema
    public void registerUser(String email, String password) {
        registeredUsers.put(email, password);
    }

    // Método para autenticar um usuário
    public boolean authenticate(String email, String password) {
        return registeredUsers.containsKey(email) && registeredUsers.get(email).equals(password);
    }
}
