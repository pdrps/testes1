package CT_02;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

// Classe que simula o sistema de indicadores
class IndicatorSystem {
    private final Map<String, String> indicators = new HashMap<>();

    // Adiciona um indicador ao sistema
    public void addIndicator(String name, String data) {
        indicators.put(name, data);
    }

    // Retorna os dados de um indicador pelo nome
    public String getIndicatorData(String name) {
        return indicators.get(name);
    }
}