package CT_02;

import CT_02.IndicatorSystem;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class IndicatorSystemTest {
    private IndicatorSystem system;

    @BeforeEach
    void setUp() {
        system = new IndicatorSystem();

        // Pré-condição: Indicadores cadastrados
        system.addIndicator("Taxa de Ocupação", "Taxa de ocupação média por setor hospitalar.");
        system.addIndicator("Custo por Paciente", "Custo médio por paciente nas unidades hospitalares.");
    }

    @Test
    void testViewTaxaDeOcupacao() {
        // Cenário: Visualizar dados do indicador "Taxa de Ocupação"
        String data = system.getIndicatorData("Taxa de Ocupação");
        assertNotNull(data, "Os dados do indicador 'Taxa de Ocupação' devem estar disponíveis.");
        assertEquals("Taxa de ocupação média por setor hospitalar.",
                data,
                "Os dados exibidos para 'Taxa de Ocupação' devem corresponder aos valores armazenados.");
    }

    @Test
    void testViewCustoPorPaciente() {
        // Cenário: Visualizar dados do indicador "Custo por Paciente"
        String data = system.getIndicatorData("Custo por Paciente");
        assertNotNull(data, "Os dados do indicador 'Custo por Paciente' devem estar disponíveis.");
        assertEquals("Custo médio por paciente nas unidades hospitalares.",
                data,
                "Os dados exibidos para 'Custo por Paciente' devem corresponder aos valores armazenados.");
    }

    @Test
    void testViewNonexistentIndicator() {
        // Cenário: Tentar visualizar dados de um indicador inexistente
        String data = system.getIndicatorData("Indicador Inexistente");
        assertNull(data, "Para um indicador inexistente, o sistema deve retornar null.");
    }
}