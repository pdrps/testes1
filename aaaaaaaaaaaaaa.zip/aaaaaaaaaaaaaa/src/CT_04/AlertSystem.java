package CT_04;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

// Classe que simula o sistema de alertas
class AlertSystem {
    private double criticalLimit;
    private final List<String> alertLog = new ArrayList<>();

    // Configura o limite crítico para o indicador
    public void setCriticalLimit(double limit) {
        this.criticalLimit = limit;
    }

    // Verifica o valor do indicador e gera alertas, se necessário
    public void evaluateIndicator(String name, double value) {
        if (value > criticalLimit) {
            alertLog.add("Alerta: " + name + " crítica: " + value + "%");
        }
    }

    // Retorna os alertas gerados
    public List<String> getAlertLog() {
        return new ArrayList<>(alertLog);
    }
}
