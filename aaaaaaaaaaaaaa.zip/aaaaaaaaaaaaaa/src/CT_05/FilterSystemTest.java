package CT_05;

import CT_05.FilterSystem;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class FilterSystemTest {
    private FilterSystem system;

    @BeforeEach
    void setUp() {
        system = new FilterSystem();

        // Pré-condição: Adicionar indicadores com diferentes categorias
        system.addIndicator("Taxa de Ocupação", "Operacionais");
        system.addIndicator("Custo por Paciente", "Operacionais");
        system.addIndicator("Taxa de Infecção", "Clínicos");
        system.addIndicator("Satisfação do Paciente", "Clínicos");
    }

    @Test
    void testFilterOperationalCategory() {
        // Cenário: Filtrar indicadores da categoria "Operacionais"
        List<Indicator> filteredIndicators = system.filterByCategory("Operacionais");

        assertEquals(2, ((List<?>) filteredIndicators).size(), "Deve haver exatamente 2 indicadores na categoria Operacionais.");
        assertTrue(filteredIndicators.stream().allMatch(i -> i.getCategory().equalsIgnoreCase("Operacionais")),
                "Todos os indicadores filtrados devem pertencer à categoria Operacionais.");
    }

    @Test
    void testFilterClinicalCategory() {
        // Cenário: Filtrar indicadores da categoria "Clínicos"
        List<Indicator> filteredIndicators = system.filterByCategory("Clínicos");

        assertEquals(2, filteredIndicators.size(), "Deve haver exatamente 2 indicadores na categoria Clínicos.");
        assertTrue(filteredIndicators.stream().allMatch(i -> i.getCategory().equalsIgnoreCase("Clínicos")),
                "Todos os indicadores filtrados devem pertencer à categoria Clínicos.");
    }

    @Test
    void testFilterNonExistentCategory() {
        // Cenário: Filtrar uma categoria inexistente
        List<Indicator> filteredIndicators = system.filterByCategory("Financeiros");

        assertTrue(filteredIndicators.isEmpty(), "Nenhum indicador deve ser retornado para categorias inexistentes.");
    }
}