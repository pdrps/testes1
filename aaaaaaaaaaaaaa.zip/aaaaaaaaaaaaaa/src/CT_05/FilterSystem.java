package CT_05;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

class FilterSystem {
    private final List<Indicator> indicators = new ArrayList<>();

    // Adiciona um indicador ao sistema
    public void addIndicator(String name, String category) {
        indicators.add(new Indicator(name, category));
    }

    // Filtra os indicadores com base na categoria
    public List<Indicator> filterByCategory(String category) {
        return indicators.stream()
                .filter(indicator -> indicator.getCategory().equalsIgnoreCase(category))
                .collect(Collectors.toList());
    }
}