package CT_03;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

// Classe que simula o sistema de indicadores com funcionalidade de busca
class IndicatorSystem {
    private final List<String> indicators = new ArrayList<>();

    // Adiciona um indicador ao sistema
    public void addIndicator(String name) {
        indicators.add(name);
    }

    // Pesquisa indicadores pelo nome ou parte dele
    public List<String> searchIndicators(String searchTerm) {
        return indicators.stream()
                .filter(indicator -> indicator.toLowerCase().contains(searchTerm.toLowerCase()))
                .collect(Collectors.toList());
    }
}