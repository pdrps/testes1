package CT_01;

import static org.junit.jupiter.api.Assertions.*;

import CT_01.MetadataSystem;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class MetadataSystemTest {
    private MetadataSystem system;

    @BeforeEach
    void setUp() {
        system = new MetadataSystem();
    }

    @Test
    void testAddNewIndicator() {
        // Cenário: Cadastrar um novo indicador
        boolean isAdded = system.addIndicator("Taxa de Ocupação", "Taxa de ocupação média por setor hospitalar");
        assertTrue(isAdded, "O indicador deveria ser cadastrado com sucesso.");
        assertEquals(1, system.getMetadataCount(), "Deve haver exatamente 1 indicador cadastrado.");
    }

    @Test
    void testUpdateIndicatorDescription() {
        // Pré-condição: Indicador cadastrado
        system.addIndicator("Taxa de Ocupação", "Taxa de ocupação média por setor hospitalar");

        // Cenário: Editar a descrição do indicador
        boolean isUpdated = system.updateIndicator("Taxa de Ocupação", "Taxa média de ocupação em todos os setores");
        assertTrue(isUpdated, "A edição da descrição do indicador deveria ser bem-sucedida.");
        assertEquals("Taxa média de ocupação em todos os setores",
                system.getDescription("Taxa de Ocupação"),
                "A descrição do indicador deve refletir a atualização.");
    }

    @Test
    void testAddDuplicateIndicator() {
        // Pré-condição: Indicador cadastrado
        system.addIndicator("Taxa de Ocupação", "Taxa de ocupação média por setor hospitalar");

        // Cenário: Tentar cadastrar um indicador com o mesmo nome
        boolean isDuplicateAdded = system.addIndicator("Taxa de Ocupação", "Outra descrição");
        assertFalse(isDuplicateAdded, "O sistema deveria bloquear a criação de indicadores com nomes duplicados.");
        assertEquals(1, system.getMetadataCount(), "O número total de indicadores não deve mudar após tentativa de duplicação.");
    }
}
