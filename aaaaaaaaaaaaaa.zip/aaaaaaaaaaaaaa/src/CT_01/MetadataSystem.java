package CT_01;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

// Mock de um sistema de metadados (para simplificar o exemplo)
class MetadataSystem {
    private final Map<String, String> metadata = new HashMap<>();

    public boolean addIndicator(String name, String description) {
        if (metadata.containsKey(name)) {
            return false; // Nome duplicado
        }
        metadata.put(name, description);
        return true;
    }

    public boolean updateIndicator(String name, String newDescription) {
        if (!metadata.containsKey(name)) {
            return false; // Indicador não existe
        }
        metadata.put(name, newDescription);
        return true;
    }

    public String getDescription(String name) {
        return metadata.get(name);
    }

    public int getMetadataCount() {
        return metadata.size();
    }
}

